package refactored;

public class VIPDiscount implements DiscountStrategy {
	
	public double applyDiscount(double total) {
		
		return total * 0.80;
	}
}
